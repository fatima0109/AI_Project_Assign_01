echo "Run the steps in README.md inside Google Colab."
