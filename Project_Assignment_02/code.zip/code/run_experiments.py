import subprocess
import sys
import os

def call_model_proposed(train_path, test_path, out_dir, text_col, label_col, epochs=2, pretrained_model="bert-base-uncased"):
    cmd = [
        sys.executable,
        os.path.join("code", "model_proposed.py"),
        "--train_path", train_path,
        "--test_path", test_path,
        "--out_dir", out_dir,
        "--text_col", text_col,
        "--label_col", label_col,
        "--pretrained_model", pretrained_model,
        "--epochs", str(epochs)
    ]
    # Run and show real-time output
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
    for line in process.stdout:
        print(line, end="")  # forward each line immediately
    process.wait()
    if process.returncode != 0:
        raise subprocess.CalledProcessError(process.returncode, cmd)
    print("model_proposed.py finished successfully.")
