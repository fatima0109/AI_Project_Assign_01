# model_proposed.py
"""
Fine-tune a transformer (HuggingFace) and save model & tokenizers.
Also exports predictions for ensemble stage.
"""
import os
import argparse
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
from datasets import Dataset
import numpy as np
import pandas as pd
import evaluate
from sklearn.utils.class_weight import compute_class_weight
from collections import Counter
import random

def simple_augment(text, p_replace=0.1):
    # very simple token-level synonym-like replacement using short heuristics
    tokens = text.split()
    n = max(1, int(len(tokens) * p_replace))
    for _ in range(n):
        i = random.randrange(len(tokens))
        tok = tokens[i]
        if len(tok) > 3 and tok.isalpha():
            if random.random() < 0.5:
                tokens[i] = tok[:-1] if len(tok) > 4 else tok
            else:
                tokens[i] = tok + tok[-1]
    return " ".join(tokens)

def prepare_hf_dataset(X_train, y_train, X_val, y_val, tokenizer):
    train_enc = tokenizer(X_train.tolist(), truncation=True, padding='max_length', max_length=256)
    val_enc = tokenizer(X_val.tolist(), truncation=True, padding='max_length', max_length=256)
    train_ds = Dataset.from_dict({**train_enc, 'labels': y_train.tolist()})
    val_ds = Dataset.from_dict({**val_enc, 'labels': y_val.tolist()})
    return train_ds, val_ds

def compute_class_weights(y):
    classes = np.unique(y)
    weights = compute_class_weight('balanced', classes=classes, y=y)
    return {int(c): float(w) for c, w in zip(classes, weights)}

def main(args):
    import os
    import pandas as pd
    from datasets import load_dataset

    # ===== Load train dataset =====
    if args.train_path.endswith(".arrow"):
        dataset = load_dataset('arrow', data_files=args.train_path)
        df_train = dataset['train'].to_pandas()
    elif args.train_path.endswith(".feather"):
        import pyarrow.feather as feather
        df_train = feather.read_feather(args.train_path)
    elif args.train_path.endswith(".parquet"):
        df_train = pd.read_parquet(args.train_path)
    else:
        raise ValueError(f"Unsupported train file format: {args.train_path}")

    # ===== Load test dataset =====
    if args.test_path.endswith(".arrow"):
        dataset = load_dataset('arrow', data_files=args.test_path)
        df_test = dataset['train'].to_pandas()
    elif args.test_path.endswith(".feather"):
        import pyarrow.feather as feather
        df_test = feather.read_feather(args.test_path)
    elif args.test_path.endswith(".parquet"):
        df_test = pd.read_parquet(args.test_path)
    else:
        raise ValueError(f"Unsupported test file format: {args.test_path}")

    # Auto-detect columns if not provided
    text_col = args.text_col or 'text'
    label_col = args.label_col or 'label'

    X = df_train[text_col].astype(str)
    y = df_train[label_col].astype(int)

    from sklearn.model_selection import train_test_split
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=args.val_size, random_state=42, stratify=y)

    # Augmentation for minority classes
    if args.augment and args.augment_times > 0:
        from collections import Counter
        import random
        counts = Counter(y_train)
        max_count = max(counts.values())
        aug_texts, aug_labels = [], []
        for lab, cnt in counts.items():
            needed = max(0, min(args.augment_times*(cnt), max_count-cnt))
            samples = [t for t, labt in zip(X_train, y_train) if labt == lab]
            for _ in range(needed):
                s = random.choice(samples)
                aug_texts.append(simple_augment(s, p_replace=0.12))
                aug_labels.append(lab)
        if aug_texts:
            X_train = pd.concat([X_train, pd.Series(aug_texts)], ignore_index=True)
            y_train = pd.concat([y_train, pd.Series(aug_labels)], ignore_index=True)

    # ===== Tokenizer & Dataset Preparation =====
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.pretrained_model)

    train_ds, val_ds = prepare_hf_dataset(X_train, y_train, X_val, y_val, tokenizer)

    # ===== Model & Training =====
    import torch
    from transformers import AutoModelForSequenceClassification, Trainer, TrainingArguments
    import numpy as np
    import evaluate

    num_labels = len(np.unique(y))
    model = AutoModelForSequenceClassification.from_pretrained(args.pretrained_model, num_labels=num_labels)

    # Class weights
    from sklearn.utils.class_weight import compute_class_weight
    classes = np.unique(y_train)
    weights = compute_class_weight('balanced', classes=classes, y=y_train)
    weight_list = [float(w) for w in weights]

    device = 0 if torch.cuda.is_available() else -1
    accuracy_metric = evaluate.load("accuracy")
    f1_metric = evaluate.load("f1")

    def compute_metrics(pred):
        logits, labels = pred
        preds = np.argmax(logits, axis=-1)
        return {
            'accuracy': accuracy_metric.compute(predictions=preds, references=labels)['accuracy'],
            'f1_macro': f1_metric.compute(predictions=preds, references=labels, average='macro')['f1']
        }

    from transformers import Trainer

    class WeightedTrainer(Trainer):
        def compute_loss(self, model, inputs, return_outputs=False):
            labels = inputs.get("labels")
            outputs = model(**inputs)
            logits = outputs.get("logits")
            loss_fct = torch.nn.CrossEntropyLoss(weight=torch.tensor(weight_list).to(model.device))
            loss = loss_fct(logits.view(-1, num_labels), labels.view(-1))
            return (loss, outputs) if return_outputs else loss

    training_args = TrainingArguments(
        output_dir=args.out_dir,                    # Where to save checkpoints
        evaluation_strategy="epoch",               # Evaluate after each epoch
        save_strategy="epoch",                     # Save after each epoch
        logging_strategy="steps",                  # Log every X steps
        logging_steps=20,                          # Adjust based on dataset size
        logging_dir=os.path.join(args.out_dir, "logs"),  # Folder for logs
        learning_rate=args.lr,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        num_train_epochs=args.epochs,
        weight_decay=0.01,
        load_best_model_at_end=True,
        metric_for_best_model="f1_macro",
        greater_is_better=True,
        fp16=torch.cuda.is_available(),            # Use mixed precision only if GPU available
        report_to="none",                           # Avoid trying to send logs to wandb/comet
        run_name="model_proposed_run",             # Optional, just a name
        save_total_limit=2                          # Keep last 2 checkpoints
    )

    print("TrainingArguments set. Using device:", "cuda" if torch.cuda.is_available() else "cpu")

    trainer = WeightedTrainer(
        model=model,
        args=training_args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        compute_metrics=compute_metrics
    )

    trainer.train()

    # Save model & tokenizer
    trainer.save_model(os.path.join(args.out_dir, 'model_proposed'))
    tokenizer.save_pretrained(os.path.join(args.out_dir, 'model_proposed'))

    # Produce val predictions and probabilities for ensemble
    preds_output = trainer.predict(val_ds)
    probs = torch.nn.functional.softmax(torch.tensor(preds_output.predictions), dim=1).numpy()
    np.save(os.path.join(args.out_dir, "val_probs.npy"), probs)
    np.save(os.path.join(args.out_dir, "val_labels.npy"), preds_output.label_ids)
    print("Saved model, val probs and labels to", args.out_dir)
